import { create } from "zustand";
import {
  createBattery,
  createBreakers,
  createDemand,
  createDevices,
  createEdge,
  createInitialHealth,
  createOpenAdr,
  createSolar,
  hydrateOpenAdrTimes,
  tickSimulation,
} from "./simulator";
import type {
  ActivityEvent,
  ActivityLevel,
  BreakerStatus,
  IpcState,
  ProductLine,
  ViewId,
} from "./types";
import { PRODUCTS } from "./constants";

interface IpcActions {
  setView: (view: ViewId) => void;
  setProduct: (product: ProductLine) => void;
  toggleBreaker: (id: string) => void;
  tripBreaker: (id: string, reason: string) => void;
  resetBreaker: (id: string) => void;
  setLoto: (id: string, loto: boolean) => void;
  selectBreaker: (id: string | null) => void;
  setOpenAdrOptIn: (id: string, optIn: boolean) => void;
  simulateBlackout: () => void;
  restoreGrid: () => void;
  triggerDemandEvent: () => void;
  pushActivity: (level: ActivityLevel, source: string, message: string) => void;
  setCommandOpen: (open: boolean) => void;
  tick: () => void;
  start: () => void;
  stop: () => void;
}

let timer: ReturnType<typeof setInterval> | null = null;
let tickCount = 0;
let actSeq = 0;
let startedOnce = false;

function activity(level: ActivityLevel, source: string, message: string): ActivityEvent {
  actSeq += 1;
  return { id: `a-${Date.now()}-${actSeq}`, t: Date.now(), level, source, message };
}

function bootstrap(product: ProductLine): IpcState {
  const breakers = createBreakers(product);
  return {
    product,
    view: "overview",
    running: false,
    health: createInitialHealth(product),
    phases: [],
    breakers,
    devices: createDevices(),
    battery: createBattery(product),
    solar: createSolar(product),
    demand: createDemand(product),
    openAdr: createOpenAdr(),
    edge: createEdge(),
    history: [],
    meshNodes: 6,
    vppRevenueUsd: 128.4,
    selectedBreakerId: null,
    // Empty until client start() — avoids SSR/client Date.now mismatch
    activity: [],
    demoHour: 13.5,
    commandOpen: false,
  };
}

export const useIpcStore = create<IpcState & IpcActions>((set, get) => ({
  ...bootstrap("R1+"),

  setView: (view) => set({ view, commandOpen: false }),

  setCommandOpen: (open) => set({ commandOpen: open }),

  setProduct: (product) => {
    const prev = get();
    const next = bootstrap(product);
    const now = Date.now();
    set({
      ...next,
      view: prev.view,
      running: prev.running,
      vppRevenueUsd: prev.vppRevenueUsd,
      openAdr: hydrateOpenAdrTimes(next.openAdr, now),
      demand: { ...next.demand, windowStart: now - 7 * 60_000 },
      activity: [
        activity("info", "System", `Product reconfigured → ${PRODUCTS[product].name}`),
        ...prev.activity,
      ].slice(0, 40),
      commandOpen: false,
    });
  },

  selectBreaker: (id) => set({ selectedBreakerId: id }),

  pushActivity: (level, source, message) => {
    set((s) => ({
      activity: [activity(level, source, message), ...s.activity].slice(0, 40),
    }));
  },

  toggleBreaker: (id) => {
    set((s) => {
      const b = s.breakers.find((x) => x.id === id);
      if (!b || b.status === "LOTO" || b.status === "TRIPPED") return s;
      const next: BreakerStatus = b.status === "CLOSED" ? "OPEN" : "CLOSED";
      return {
        breakers: s.breakers.map((x) =>
          x.id !== id
            ? x
            : {
                ...x,
                status: next,
                cycleCount: x.cycleCount + 1,
                currentA: next === "OPEN" ? 0 : x.currentA,
                powerW: next === "OPEN" ? 0 : x.powerW,
              },
        ),
        activity: [
          activity("info", "Breaker", `${b.label} → ${next}`),
          ...s.activity,
        ].slice(0, 40),
      };
    });
  },

  tripBreaker: (id, reason) => {
    set((s) => {
      const b = s.breakers.find((x) => x.id === id);
      return {
        breakers: s.breakers.map((x) =>
          x.id === id
            ? { ...x, status: "TRIPPED" as const, currentA: 0, powerW: 0, cycleCount: x.cycleCount + 1 }
            : x,
        ),
        health: { ...s.health, lastTrip: reason },
        activity: [
          activity("danger", "Trip", reason || `${b?.label ?? id} software trip`),
          ...s.activity,
        ].slice(0, 40),
      };
    });
  },

  resetBreaker: (id) => {
    set((s) => {
      const b = s.breakers.find((x) => x.id === id);
      return {
        breakers: s.breakers.map((x) =>
          x.id === id && (x.status === "TRIPPED" || x.status === "OPEN")
            ? { ...x, status: "CLOSED" as const }
            : x,
        ),
        activity: b
          ? [activity("ok", "Breaker", `${b.label} reset to CLOSED`), ...s.activity].slice(0, 40)
          : s.activity,
      };
    });
  },

  setLoto: (id, loto) => {
    set((s) => {
      const b = s.breakers.find((x) => x.id === id);
      return {
        breakers: s.breakers.map((x) => {
          if (x.id !== id) return x;
          if (loto) return { ...x, status: "LOTO" as const, currentA: 0, powerW: 0 };
          return { ...x, status: "OPEN" as const };
        }),
        activity: b
          ? [
              activity("warn", "LOTO", `${b.label} ${loto ? "engaged" : "released"}`),
              ...s.activity,
            ].slice(0, 40)
          : s.activity,
      };
    });
  },

  setOpenAdrOptIn: (id, optIn) => {
    set((s) => ({
      openAdr: s.openAdr.map((e) =>
        e.id === id
          ? {
              ...e,
              optIn,
              status:
                !optIn && e.status === "PENDING"
                  ? ("OPTED_OUT" as const)
                  : e.status === "OPTED_OUT" && optIn
                    ? ("PENDING" as const)
                    : e.status,
            }
          : e,
      ),
      activity: [
        activity("info", "OpenADR", `Event ${id} opt-${optIn ? "in" : "out"}`),
        ...s.activity,
      ].slice(0, 40),
    }));
  },

  simulateBlackout: () => {
    set((s) => ({
      health: { ...s.health, gridMode: "ISLAND" },
      breakers: s.breakers.map((b) =>
        b.shedCapable && !b.critical && b.status === "CLOSED"
          ? { ...b, status: "OPEN" as const, powerW: 0, currentA: 0, cycleCount: b.cycleCount + 1 }
          : b,
      ),
      activity: [
        activity("warn", "Grid", "Mains lost — island mode · virtual subpanel active"),
        ...s.activity,
      ].slice(0, 40),
    }));
  },

  restoreGrid: () => {
    set((s) => ({
      health: { ...s.health, gridMode: "GRID" },
      breakers: s.breakers.map((b) =>
        b.status === "OPEN" && !b.critical ? { ...b, status: "CLOSED" as const } : b,
      ),
      activity: [activity("ok", "Grid", "Utility restored — loads re-sequenced"), ...s.activity].slice(
        0,
        40,
      ),
    }));
  },

  triggerDemandEvent: () => {
    const now = Date.now();
    set((s) => ({
      openAdr: [
        {
          id: `evt-manual-${now}`,
          name: "Manual Demand Response",
          startAt: now,
          durationMin: 15,
          targetReductionKw: 3.5,
          status: "ACTIVE",
          optIn: true,
        },
        ...s.openAdr,
      ],
      demand: { ...s.demand, shedding: true },
      activity: [
        activity("warn", "VPP", "Manual DR event injected · shedding non-critical load"),
        ...s.activity,
      ].slice(0, 40),
    }));
  },

  tick: () => {
    const s = get();
    tickCount += 1;
    const demoHour = (13.2 + tickCount * 0.035) % 24;
    const prevMode = s.health.gridMode;
    const prevShed = s.demand.shedding;
    const out = tickSimulation(
      {
        product: s.product,
        breakers: s.breakers,
        devices: s.devices,
        battery: s.battery,
        solar: s.solar,
        demand: s.demand,
        openAdr: s.openAdr,
        edge: s.edge,
        health: s.health,
        history: s.history,
        tick: tickCount,
        demoHour,
      },
      s.vppRevenueUsd,
    );

    const extra: ActivityEvent[] = [];
    if (out.health.gridMode !== prevMode) {
      extra.push(activity("warn", "Grid", `Mode change ${prevMode} → ${out.health.gridMode}`));
    }
    if (out.demand.shedding && !prevShed) {
      extra.push(activity("warn", "Demand", "Peak forecast breach — autonomous shed armed"));
    }
    if (out.edge.mode !== s.edge.mode) {
      extra.push(activity("info", "Edge", `TPU mode → ${out.edge.mode}`));
    }
    const newlyTripped = out.breakers.filter(
      (b) => b.status === "TRIPPED" && s.breakers.find((x) => x.id === b.id)?.status !== "TRIPPED",
    );
    for (const b of newlyTripped) {
      extra.push(activity("danger", "Trip", `${b.label} Class 10/20 overcurrent`));
    }

    set({
      breakers: out.breakers,
      devices: out.devices,
      battery: out.battery,
      solar: out.solar,
      demand: out.demand,
      openAdr: out.openAdr,
      edge: out.edge,
      health: out.health,
      phases: out.phases,
      history: out.history,
      meshNodes: out.meshNodes,
      vppRevenueUsd: out.vppRevenueUsd,
      demoHour,
      activity: extra.length ? [...extra, ...s.activity].slice(0, 40) : s.activity,
    });
  },

  start: () => {
    if (timer) return;
    const s = get();
    const now = Date.now();
    if (!startedOnce) {
      startedOnce = true;
      set({
        openAdr: hydrateOpenAdrTimes(s.openAdr, now),
        demand: { ...s.demand, windowStart: now - 7 * 60_000 },
        activity: [
          activity("ok", "Core", `${PRODUCTS[s.product].name} controller online`),
          activity("info", "NILM", "Edge TPU model loaded · int8 · Coral"),
          activity("info", "Comms", "mTLS mesh handshake complete"),
        ],
      });
    }
    set({ running: true });
    get().tick();
    timer = setInterval(() => get().tick(), 1000);
  },

  stop: () => {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
    set({ running: false });
  },
}));

export function getProductSpec(product: ProductLine) {
  return PRODUCTS[product];
}

export const VIEW_META: { id: ViewId; label: string; hint: string }[] = [
  { id: "overview", label: "Overview", hint: "Live telemetry & panel faceplate" },
  { id: "circuits", label: "Circuits", hint: "Hybrid breakers & LOTO" },
  { id: "nilm", label: "NILM Engine", hint: "Load disaggregation" },
  { id: "load", label: "Load Mgmt", hint: "Demand window & virtual subpanel" },
  { id: "vpp", label: "VPP / OpenADR", hint: "Grid services & droop" },
  { id: "prototypes", label: "Prototypes", hint: "Hardware concept gallery" },
  { id: "blueprints", label: "Blueprints", hint: "Engineering drawing package" },
  { id: "architecture", label: "Architecture", hint: "System topology" },
];
